package com.enumerations;

public enum BrowserType {
	Chrome,
	Firefox,
	InternetExplorer
}
